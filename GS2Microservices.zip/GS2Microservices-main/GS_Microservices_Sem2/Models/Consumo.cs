﻿namespace GSMicroservices.Models
{
    public class Consumo
    {
        public int Id { get; set; }             
        public string NomeAparelho { get; set; }   
        public double ConsumoMedio { get; set; }    

    }
}
