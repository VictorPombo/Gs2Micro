﻿using MongoDB.Driver;

namespace GSMicroservices.Services
{
    public interface IMongoService
    {
        IMongoCollection<T> GetCollection<T>(string collectionName);
    }
}
